"""Brute-force all known signatures/keys against a type-4 config.bin"""
import sys
from io import BytesIO
from types import SimpleNamespace

import zcu
from zcu import known_keys
from zcu.xcryptors import CBCXcryptor

INFILE = r"C:\Users\ykswx\Downloads\config.bin"
OUTFILE = r"C:\Users\ykswx\Downloads\config.xml"

# Candidate signature strings to try
candidate_sigs = set()
for sigs in known_keys.KNOWN_KEYGENS.values():
    for s in sigs:
        candidate_sigs.add(s)
for s in known_keys.KNOWN_SIGNATURES:
    candidate_sigs.add(s)
for m in known_keys.KNOWN_MODELS:
    candidate_sigs.add(m)
for key, sigs in known_keys.KNOWN_KEYS.items():
    for s in sigs:
        candidate_sigs.add(s.upper())
# common extras
candidate_sigs.update([
    "", "ZXHN H168N V3.5", "ZXHN H298Q", "ZXHN H268Q", "ZXHN H298A",
    "ZXHN H267A V1.0", "H298A", "H288A", "H188A", "H196Q",
])

# Build candidate (key, iv, label) list
candidates = []
seen = set()

def add(key, iv, label):
    if (key, iv) not in seen:
        seen.add((key, iv))
        candidates.append((key, iv, label))

SERIAL = "HN5YY13RAW02763"
MAC = "7c:7d:21:b9:44:e6"
candidate_sigs.update(["SR1010", "ZXSLC SR1010", "ZXSLC", "ZXSLCSR1010"])

# 1. run every keygen for every candidate signature, with serial/mac empty AND with real serial
for sig in candidate_sigs:
    for serial in ("", SERIAL):
        for mac in ("", MAC):
            for lp in ("", SERIAL):
                p = SimpleNamespace(signature=sig, serial=serial, mac=mac, longPass=lp)
                for gen in known_keys.KNOWN_KEYGENS.keys():
                    r = gen(p)
                    if r:
                        add(r[0], r[1], f"keygen sig='{sig}' serial='{serial}' mac='{mac}' lp='{lp}' -> {r[2]}")

# 1b. serial-based with assorted known prefixes
prefix_pairs = [
    ("8cc72b05705d5c46", "667b02a85c61c786"),
    ("8cc72b05705d5c46f412af8cbed55aa", "667b02a85c61c786def4521b060265e"),
    ("", ""),
]
for kp, ip in prefix_pairs:
    add(kp + SERIAL, ip + SERIAL, f"serial prefix '{kp}'")
    add(SERIAL + kp, SERIAL + ip, f"serial suffix '{kp}'")
    add(SERIAL, SERIAL, "serial as key=iv")

# 2. static KNOWN_KEYS as CBC key=iv (type-3 style) and key with iv=key
for k in known_keys.get_all_keys():
    add(k, k, f"static-key '{k}'")

print(f"Total candidates: {len(candidates)}")

def try_key(key, iv):
    with open(INFILE, "rb") as infile:
        zcu.zte.read_header(infile)
        zcu.zte.read_signature(infile)
        ptype = zcu.zte.read_payload_type(infile)
        dec = CBCXcryptor()
        dec.set_key(key, iv)
        decrypted = dec.decrypt(infile)
        if zcu.zte.read_payload_type(decrypted, raise_on_error=False) is not None:
            decompressed, _ = zcu.compression.decompress(decrypted)
            return decompressed.read()
    return None

for key, iv, label in candidates:
    try:
        out = try_key(key, iv)
    except Exception:
        out = None
    if out:
        with open(OUTFILE, "wb") as f:
            f.write(out)
        print(f"\nSUCCESS! key='{key}' iv='{iv}'\n  source: {label}")
        print(f"  wrote {len(out)} bytes to {OUTFILE}")
        sys.exit(0)

print("No candidate key worked.")
sys.exit(1)
